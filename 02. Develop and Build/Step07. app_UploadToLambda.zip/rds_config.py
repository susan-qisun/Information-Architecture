#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#config file containing credentials for RDS MySQL instance
db_username = "admin"
db_password = "Susan830"
db_name = "applicant_twitter" 

